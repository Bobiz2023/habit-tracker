import React, { useState } from 'react';
import './App.css';

const habitsList = [
  { id: 1, name: 'Exercise' },
  { id: 2, name: 'Read' },
  { id: 3, name: 'Meditate' }
];

function App() {
  const [habits, setHabits] = useState(
    habitsList.map(habit => ({ ...habit, completed: false }))
  );

  const toggleHabit = (id) => {
    setHabits(habits.map(habit => 
      habit.id === id ? { ...habit, completed: !habit.completed } : habit
    ));
  };

  return (
    <div className='app'>
      <h1>Habit Tracker</h1>
      <ul>
        {habits.map(habit => (
          <li key={habit.id} className={habit.completed ? 'completed' : ''}>
            {habit.name}
            <button onClick={() => toggleHabit(habit.id)}>
              {habit.completed ? 'Undo' : 'Complete'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;