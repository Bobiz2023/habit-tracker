import React, { useState, useEffect } from 'react';
import { auth, db } from './firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "firebase/auth";
import { collection, addDoc, getDocs, deleteDoc, doc, updateDoc } from "firebase/firestore";
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [habits, setHabits] = useState([]);
  const [newHabit, setNewHabit] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchHabits();
    }
  }, [user]);

  const fetchHabits = async () => {
    setLoading(true);
    const querySnapshot = await getDocs(collection(db, "habits"));
    setHabits(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    setLoading(false);
  };

  const handleSignUp = async () => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    setUser(userCredential.user);
  };

  const handleLogin = async () => {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    setUser(userCredential.user);
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    setHabits([]);
  };

  const addHabit = async () => {
    if (newHabit.trim()) {
      const docRef = await addDoc(collection(db, "habits"), { name: newHabit, user: user.uid, completedDays: [] });
      setHabits([...habits, { id: docRef.id, name: newHabit, completedDays: [] }]);
      setNewHabit("");
    }
  };

  const toggleCompletion = async (habitId, day) => {
    const habitRef = doc(db, "habits", habitId);
    const habit = habits.find(h => h.id === habitId);
    let updatedDays = habit.completedDays.includes(day)
      ? habit.completedDays.filter(d => d !== day)
      : [...habit.completedDays, day];

    await updateDoc(habitRef, { completedDays: updatedDays });
    setHabits(habits.map(h => (h.id === habitId ? { ...h, completedDays: updatedDays } : h)));
  };

  const deleteHabit = async (habitId) => {
    await deleteDoc(doc(db, "habits", habitId));
    setHabits(habits.filter(h => h.id !== habitId));
  };

  return (
    <div className="app">
      <h1>Habit Tracker</h1>
      <p>From DrMikachu to Twixim</p>

      {!user ? (
        <div className="auth">
          <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button onClick={handleSignUp}>Sign Up</button>
          <button onClick={handleLogin}>Login</button>
        </div>
      ) : (
        <>
          <button onClick={handleLogout}>Logout</button>
          <div className="habit-input">
            <input type="text" value={newHabit} onChange={(e) => setNewHabit(e.target.value)} placeholder="Enter new habit..." />
            <button onClick={addHabit}>Add Habit</button>
          </div>
          {loading ? <p>Loading habits...</p> : (
            <div className="habits-list">
              {habits.map(habit => (
                <div key={habit.id} className="habit-container">
                  <h3>{habit.name}</h3>
                  <div className="calendar">
                    {[...Array(7)].map((_, index) => (
                      <span 
                        key={index} 
                        className={habit.completedDays.includes(index) ? "day completed" : "day"}
                        onClick={() => toggleCompletion(habit.id, index)}
                      >
                        {["S", "M", "T", "W", "T", "F", "S"][index]}
                      </span>
                    ))}
                  </div>
                  <button className="delete" onClick={() => deleteHabit(habit.id)}>Delete</button>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default App;
